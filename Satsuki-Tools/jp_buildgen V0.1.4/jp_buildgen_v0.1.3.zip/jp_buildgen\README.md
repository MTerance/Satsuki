# JP Building Generator 0.1.3

- Textures par catégorie: placer vos images dans `jp_buildgen/textures/<categorie>/(concrete|glass|roof|ground|signage).png`.
- Catégories: office, mall, restaurant, konbini, apartment, house (ou AUTO selon le type).
- Matériaux image (projection Box, coord Object); fallback procédural si image absente.
- Éléments façade collés (pas de flottement visuel).
- Parcelle : trottoir avant + marges fines.
