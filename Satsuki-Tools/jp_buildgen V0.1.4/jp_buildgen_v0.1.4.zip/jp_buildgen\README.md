# JP Building Generator 0.1.4

- Textures par catégorie: placer vos images dans `jp_buildgen/textures/<categorie>/(concrete|glass|roof|ground|signage).png`.
- Catégories: office, mall, restaurant, konbini, apartment, house (ou AUTO selon le type).
- Matériaux image (projection Box, coord Object); fallback procédural si image absente.
- Éléments façade collés (pas de flottement visuel).
- Parcelle : sol plan à Z=0 + trottoir avant + marges fines.
- Ancrage parfait : origine des mesh au bottom center pour positionnement précis.
