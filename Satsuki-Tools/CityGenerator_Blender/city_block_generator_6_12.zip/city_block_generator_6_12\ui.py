import bpy
import traceback

class CITYGEN_PT_Panel(bpy.types.Panel):
    bl_label = "City Block Generator"
    bl_idname = "CITYGEN_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'CityGen'

    def draw(self, context):
        """Interface utilisateur simplifiée et robuste"""
        layout = self.layout
        
        # Vérifier l'existence des propriétés
        if not hasattr(context.scene, 'citygen_props'):
            layout.alert = True
            layout.label(text="Propriétés non initialisées", icon='ERROR')
            layout.label(text="Redémarrez Blender ou rechargez l'addon")
            return
        
        # Vérification robuste des propriétés
        if not hasattr(context.scene, 'citygen_props'):
            layout.label(text="❌ Propriétés non initialisées", icon='ERROR')
            layout.label(text="Redémarrez Blender ou rechargez l'addon")
            return
        
        props = context.scene.citygen_props
        
        # Interface des paramètres de base - TOUJOURS VISIBLE
        box = layout.box()
        box.label(text="Paramètres de base:", icon='SETTINGS')
        
        # Largeur et longueur - propriétés essentielles
        try:
            if hasattr(props, 'width'):
                box.prop(props, "width", text="Largeur")
            else:
                box.label(text="❌ Propriété 'width' manquante", icon='ERROR')
                
            if hasattr(props, 'length'):
                box.prop(props, "length", text="Longueur") 
            else:
                box.label(text="❌ Propriété 'length' manquante", icon='ERROR')
                
            if hasattr(props, 'max_floors'):
                box.prop(props, "max_floors", text="Étages max")
            else:
                box.label(text="❌ Propriété 'max_floors' manquante", icon='ERROR')
                
        except AttributeError as e:
            box.label(text=f"ERREUR propriétés: {e}", icon='ERROR')
        
        # Vérifier l'existence de shape_mode avant de l'afficher
        if hasattr(props, 'shape_mode'):
            box.prop(props, "shape_mode", text="Forme des bâtiments")
        
        # Section Infrastructure
        layout.separator()
        infrastructure_box = layout.box()
        infrastructure_box.label(text="Infrastructure:", icon='MOD_BUILD')
        
        # Vérifier l'existence avant d'afficher chaque propriété
        if hasattr(props, 'road_width'):
            infrastructure_box.prop(props, "road_width", text="Largeur routes")
        if hasattr(props, 'sidewalk_width'):
            infrastructure_box.prop(props, "sidewalk_width", text="Largeur trottoirs")
        
        # Routes diagonales
        if hasattr(props, 'enable_diagonal_roads'):
            infrastructure_box.separator()
            infrastructure_box.prop(props, "enable_diagonal_roads", text="🔀 Routes diagonales")
            if props.enable_diagonal_roads and hasattr(props, 'diagonal_road_frequency'):
                infrastructure_box.prop(props, "diagonal_road_frequency", text="Fréquence (%)", slider=True)
        
        # Carrefours
        if hasattr(props, 'enable_intersections'):
            infrastructure_box.prop(props, "enable_intersections", text="⚡ Carrefours")
            if props.enable_intersections and hasattr(props, 'intersection_size_factor'):
                infrastructure_box.prop(props, "intersection_size_factor", text="Taille carrefours", slider=True)
        
        # Section paramètres avancés
        layout.separator()
        advanced_box = layout.box()
        advanced_box.label(text="Paramètres avancés:", icon='PREFERENCES')
        
        if hasattr(props, 'base_block_size'):
            advanced_box.prop(props, "base_block_size", text="Taille de bloc de base")
        if hasattr(props, 'block_variety'):
            advanced_box.prop(props, "block_variety", text="Variété des blocs")
        if hasattr(props, 'district_mode'):
            advanced_box.prop(props, "district_mode", text="Mode quartiers")
        
        # Configuration des districts
        if hasattr(props, 'district_mode') and props.district_mode:
            advanced_box.separator()
            advanced_box.label(text="Configuration des districts:", icon='SETTINGS')
            
            # Sélecteur de type de district
            if hasattr(props, 'district_type'):
                advanced_box.prop(props, "district_type", text="Type de district")
                
                # Afficher les ratios seulement pour le mode mixte
                if props.district_type == 'MIXED':
                    advanced_box.separator()
                    advanced_box.label(text="Ratios pour mode mixte:", icon='SETTINGS')
                    if hasattr(props, 'commercial_ratio'):
                        advanced_box.prop(props, "commercial_ratio", text="🏢 Commercial", slider=True)
                    if hasattr(props, 'residential_ratio'):
                        advanced_box.prop(props, "residential_ratio", text="🏠 Résidentiel", slider=True)
                    if hasattr(props, 'industrial_ratio'):
                        advanced_box.prop(props, "industrial_ratio", text="🏭 Industriel", slider=True)
                else:
                    # Information sur le type de district sélectionné
                    district_info = {
                        'RESIDENTIAL': "🏠 Maisons et appartements résidentiels",
                        'COMMERCIAL': "🏢 Magasins et bureaux commerciaux", 
                        'INDUSTRIAL': "🏭 Usines et entrepôts industriels",
                        'DOWNTOWN': "🌆 Gratte-ciels et tours de bureaux",
                        'SUBURBAN': "🏘️ Maisons individuelles et jardins",
                        'BUSINESS': "💼 Tours d'affaires et complexes de bureaux"
                    }
                    if props.district_type in district_info:
                        advanced_box.separator()
                        info_row = advanced_box.row()
                        info_row.label(text=district_info[props.district_type], icon='INFO')
            
            # Information sur les matériaux
            advanced_box.separator()
            info_row = advanced_box.row()
            info_row.label(text="💡 Zones colorées automatiquement", icon='INFO')
        
        # Section des actions
        layout.separator()
        action_box = layout.box()
        action_box.label(text="Actions:", icon='PLAY')
        
        # Boutons d'action
        col = action_box.column(align=True)
        col.scale_y = 1.2
        col.operator("citygen.generate_city", text="Générer Quartier", icon='MESH_CUBE')
        col.operator("citygen.regenerate_roads_sidewalks", text="Régénérer Routes", icon='MOD_BUILD')
        col.separator()
        col.operator("citygen.update_colors", text="Mettre à jour Couleurs", icon='COLOR')
        col.separator()
        col.operator("citygen.diagnostic", text="Diagnostic", icon='CONSOLE')
        
        # Section rechargement
        reload_row = col.row(align=True)
        reload_row.operator("citygen.quick_reload", text="Rechargement Rapide", icon='FILE_REFRESH')
        reload_row.operator("citygen.reload_addon", text="Rechargement Complet", icon='RECOVER_LAST')
        
        # Bouton de déploiement
        col.operator("citygen.deploy_addon", text="Déployer Addon", icon='EXPORT')
        
        # Informations
        layout.separator()
        info_box = layout.box()
        info_box.label(text="Conseils:", icon='INFO')
        info_box.label(text="• Grilles > 10x10 = lent")
        info_box.label(text="• Sauvegardez avant génération")

classes = [CITYGEN_PT_Panel]

def register():
    """Enregistre l'interface avec gestion d'erreurs"""
    try:
        for cls in classes:
            bpy.utils.register_class(cls)
            print(f"Interface {cls.__name__} enregistrée avec succès")
    except Exception as e:
        print(f"ERREUR lors de l'enregistrement de l'interface: {str(e)}")
        print(f"Traceback: {traceback.format_exc()}")

def unregister():
    """Désenregistre l'interface avec gestion d'erreurs"""
    try:
        for cls in reversed(classes):
            bpy.utils.unregister_class(cls)
            print(f"Interface {cls.__name__} désenregistrée avec succès")
    except Exception as e:
        print(f"ERREUR lors du désenregistrement de l'interface: {str(e)}")
        print(f"Traceback: {traceback.format_exc()}")