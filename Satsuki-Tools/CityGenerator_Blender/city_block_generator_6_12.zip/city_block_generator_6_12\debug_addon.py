# Script de Débogage City Block Generator

import bpy

def debug_citygen_addon():
    """Script de débogage pour diagnostiquer les problèmes de génération"""
    
    print("=== DÉBUT DÉBOGAGE CITY BLOCK GENERATOR ===")
    
    # 1. Vérifier l'existence des propriétés
    print("\n1. VÉRIFICATION DES PROPRIÉTÉS:")
    if hasattr(bpy.context.scene, 'citygen_props'):
        props = bpy.context.scene.citygen_props
        print(f"✓ Propriétés trouvées")
        print(f"  Width: {props.width}")
        print(f"  Length: {props.length}")
        print(f"  Max Floors: {props.max_floors}")
        if hasattr(props, 'district_mode'):
            print(f"  District Mode: {props.district_mode}")
        if hasattr(props, 'district_type'):
            print(f"  District Type: {props.district_type}")
        if hasattr(props, 'base_block_size'):
            print(f"  Base Block Size: {props.base_block_size}")
    else:
        print("✗ Propriétés citygen_props NON TROUVÉES")
        return
    
    # 2. Vérifier les objets existants
    print("\n2. OBJETS DANS LA SCÈNE:")
    total_objects = len(bpy.context.scene.objects)
    print(f"  Total objets: {total_objects}")
    
    # Compter par type
    roads = [obj for obj in bpy.context.scene.objects if 'road' in obj.name.lower() or 'route' in obj.name.lower()]
    sidewalks = [obj for obj in bpy.context.scene.objects if 'sidewalk' in obj.name.lower() or 'trottoir' in obj.name.lower()]
    buildings = [obj for obj in bpy.context.scene.objects if 'building' in obj.name.lower() or 'batiment' in obj.name.lower()]
    intersections = [obj for obj in bpy.context.scene.objects if 'intersection' in obj.name.lower() or 'carrefour' in obj.name.lower()]
    
    print(f"  Routes: {len(roads)}")
    for road in roads[:3]:  # Afficher les 3 premiers
        print(f"    - {road.name}")
    
    print(f"  Trottoirs: {len(sidewalks)}")
    for sidewalk in sidewalks[:3]:
        print(f"    - {sidewalk.name}")
    
    print(f"  Bâtiments: {len(buildings)}")
    for building in buildings[:3]:
        print(f"    - {building.name}")
    
    print(f"  Intersections: {len(intersections)}")
    for intersection in intersections[:3]:
        print(f"    - {intersection.name}")
    
    # 3. Vérifier les matériaux
    print("\n3. MATÉRIAUX:")
    road_mat = bpy.data.materials.get("RoadMat")
    side_mat = bpy.data.materials.get("SidewalkMat")  
    build_mat = bpy.data.materials.get("BuildingMat")
    
    print(f"  RoadMat: {'✓' if road_mat else '✗'}")
    print(f"  SidewalkMat: {'✓' if side_mat else '✗'}")
    print(f"  BuildingMat: {'✓' if build_mat else '✗'}")
    
    # 4. Test de génération simple
    print("\n4. TEST DE GÉNÉRATION:")
    try:
        # Configuration de test simple
        props.width = 2
        props.length = 2
        props.max_floors = 4
        if hasattr(props, 'district_mode'):
            props.district_mode = True
        if hasattr(props, 'district_type'):
            props.district_type = 'RESIDENTIAL'
        
        print("  Configuration de test appliquée (2x2, résidentiel)")
        print("  Lancez maintenant la génération depuis l'interface Blender")
        
    except Exception as e:
        print(f"  ✗ Erreur lors de la configuration: {e}")
    
    print("\n=== FIN DÉBOGAGE ===")
    print("\nSI AUCUN BÂTIMENT N'APPARAÎT:")
    print("1. Vérifiez que 'District Mode' est activé")
    print("2. Essayez différents types de districts")
    print("3. Augmentez 'Max Floors' si nécessaire")
    print("4. Vérifiez la console Blender pour les messages d'erreur")

# Lancer le débogage
if __name__ == "__main__":
    debug_citygen_addon()
