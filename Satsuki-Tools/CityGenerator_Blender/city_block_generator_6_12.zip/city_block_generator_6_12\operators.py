import bpy
import traceback
import sys
import importlib
# Import différé de generator pour éviter les crashes au chargement

# Fonction de rappel pour initialiser les propriétés lors du changement de scène
# Utilisation conditionnelle du décorateur persistent
def init_citygen_props(scene):
    """Initialise les propriétés City Generator pour chaque scène"""
    try:
        if hasattr(scene, 'citygen_props'):
            props = scene.citygen_props
            # Vérifier et initialiser les propriétés manquantes
            if not hasattr(props, 'width') or props.width == 0:
                props.width = 5
            if not hasattr(props, 'length') or props.length == 0:
                props.length = 5
            if not hasattr(props, 'max_floors') or props.max_floors == 0:
                props.max_floors = 8
            # Continuer pour les autres propriétés...
    except Exception as e:
        print(f"Erreur lors de l'initialisation des propriétés: {e}")

# Fonction pour s'assurer que les propriétés sont disponibles
def ensure_citygen_props(context):
    """S'assure que les propriétés City Generator sont disponibles - version tolérante"""
    try:
        if not hasattr(context.scene, 'citygen_props'):
            return False
        
        # Test simple d'existence - ne teste plus l'accès complet
        props = context.scene.citygen_props
        return props is not None
    except:
        return False

class CITYGEN_OT_Generate(bpy.types.Operator):
    bl_idname = "citygen.generate_city"
    bl_label = "Générer Quartier"
    bl_description = "Génère un quartier complet avec bâtiments, routes et trottoirs"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        try:
            # Validation préliminaire du contexte
            if not context:
                self.report({'ERROR'}, "Contexte Blender invalide")
                return {'CANCELLED'}
            
            if not hasattr(context.scene, 'citygen_props'):
                self.report({'ERROR'}, "Propriétés City Generator non initialisées")
                return {'CANCELLED'}
            
            # Import différé pour éviter les crashes de chargement
            try:
                from .generator import generate_city
            except Exception as import_error:
                self.report({'ERROR'}, f"Impossible d'importer le générateur: {import_error}")
                return {'CANCELLED'}
            
            # Tentative de génération
            success = generate_city(context)
            
            if success:
                self.report({'INFO'}, "Quartier généré avec succès")
                return {'FINISHED'}
            else:
                self.report({'ERROR'}, "Échec de la génération du quartier")
                return {'CANCELLED'}
                
        except Exception as e:
            error_msg = f"Erreur lors de la génération: {str(e)}"
            print(f"ERREUR CRITIQUE dans CITYGEN_OT_Generate: {error_msg}")
            print(f"Traceback: {traceback.format_exc()}")
            self.report({'ERROR'}, error_msg)
            return {'CANCELLED'}

class CITYGEN_OT_RegenRoads(bpy.types.Operator):
    bl_idname = "citygen.regenerate_roads_sidewalks"
    bl_label = "Régénérer Routes + Trottoirs"
    bl_description = "Régénère seulement les routes et trottoirs en gardant les bâtiments"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        try:
            # Validation préliminaire du contexte
            if not context:
                self.report({'ERROR'}, "Contexte Blender invalide")
                return {'CANCELLED'}
            
            if not hasattr(context.scene, 'citygen_props'):
                self.report({'ERROR'}, "Propriétés City Generator non initialisées")
                return {'CANCELLED'}
            
            # Import différé pour éviter les crashes de chargement
            try:
                from .generator import regenerate_roads_and_sidewalks
            except Exception as import_error:
                self.report({'ERROR'}, f"Impossible d'importer le générateur: {import_error}")
                return {'CANCELLED'}
            
            # Tentative de régénération
            success = regenerate_roads_and_sidewalks(context)
            
            if success:
                self.report({'INFO'}, "Routes et trottoirs régénérés avec succès")
                return {'FINISHED'}
            else:
                self.report({'ERROR'}, "Échec de la régénération des routes et trottoirs")
                return {'CANCELLED'}
                
        except Exception as e:
            error_msg = f"Erreur lors de la régénération: {str(e)}"
            print(f"ERREUR CRITIQUE dans CITYGEN_OT_RegenRoads: {error_msg}")
            print(f"Traceback: {traceback.format_exc()}")
            self.report({'ERROR'}, error_msg)
            return {'CANCELLED'}

class CITYGEN_OT_ReloadAddon(bpy.types.Operator):
    bl_idname = "citygen.reload_addon"
    bl_label = "Recharger Addon"
    bl_description = "Recharge complètement l'addon City Block Generator (désenregistre puis ré-enregistre)"
    bl_options = {'REGISTER'}
    
    def execute(self, context):
        try:
            print("=== DÉBUT RECHARGEMENT ADDON CITY BLOCK GENERATOR ===")
            
            import importlib
            import sys
            
            # Nom du module principal de l'addon
            addon_module_name = "city_block_generator_6_12"
            
            # Sauvegarder les valeurs des propriétés actuelles
            current_props = {}
            if hasattr(context.scene, 'citygen_props'):
                props = context.scene.citygen_props
                try:
                    current_props = {
                        'width': getattr(props, 'width', 5),
                        'length': getattr(props, 'length', 5),
                        'max_floors': getattr(props, 'max_floors', 8),
                        'road_width': getattr(props, 'road_width', 4.0),
                    }
                    print(f"Propriétés sauvegardées: {current_props}")
                except Exception as e:
                    print(f"Erreur sauvegarde propriétés: {e}")
            
            # Étape 1: Désenregistrer l'addon
            print("Désenregistrement de l'addon...")
            try:
                # Importer le module principal pour accéder à unregister
                if addon_module_name in sys.modules:
                    addon_module = sys.modules[addon_module_name]
                    if hasattr(addon_module, 'unregister'):
                        addon_module.unregister()
                        print("✅ Addon désenregistré")
                    else:
                        print("⚠️ Fonction unregister non trouvée")
                else:
                    print("⚠️ Module addon non trouvé dans sys.modules")
            except Exception as e:
                print(f"⚠️ Erreur lors du désenregistrement: {e}")
            
            # Étape 2: Recharger tous les modules
            print("Rechargement des modules...")
            modules_to_reload = [
                f"{addon_module_name}.generator",
                f"{addon_module_name}.operators", 
                f"{addon_module_name}.ui",
                addon_module_name
            ]
            
            for module_name in modules_to_reload:
                if module_name in sys.modules:
                    try:
                        importlib.reload(sys.modules[module_name])
                        print(f"✅ Module {module_name} rechargé")
                    except Exception as e:
                        print(f"❌ Erreur rechargement {module_name}: {e}")
                else:
                    print(f"⚠️ Module {module_name} non trouvé")
            
            # Étape 3: Ré-enregistrer l'addon
            print("Ré-enregistrement de l'addon...")
            try:
                if addon_module_name in sys.modules:
                    addon_module = sys.modules[addon_module_name]
                    if hasattr(addon_module, 'register'):
                        addon_module.register()
                        print("✅ Addon ré-enregistré")
                    else:
                        print("❌ Fonction register non trouvée")
                        raise Exception("Fonction register manquante")
                else:
                    print("❌ Module addon non trouvé après rechargement")
                    raise Exception("Module addon non trouvé")
            except Exception as e:
                print(f"❌ Erreur lors du ré-enregistrement: {e}")
                self.report({'ERROR'}, f"Erreur ré-enregistrement: {str(e)}")
                return {'CANCELLED'}
            
            # Étape 4: Restaurer les propriétés sauvegardées
            print("Restauration des propriétés...")
            try:
                if current_props and hasattr(context.scene, 'citygen_props'):
                    props = context.scene.citygen_props
                    for key, value in current_props.items():
                        if hasattr(props, key):
                            setattr(props, key, value)
                    print("✅ Propriétés restaurées")
                else:
                    print("⚠️ Pas de propriétés à restaurer")
            except Exception as e:
                print(f"⚠️ Erreur restauration propriétés: {e}")
            
            # Étape 5: Forcer la mise à jour de l'interface
            print("Mise à jour de l'interface...")
            try:
                for area in context.screen.areas:
                    if area.type == 'VIEW_3D':
                        for region in area.regions:
                            if region.type == 'UI':
                                region.tag_redraw()
                print("✅ Interface mise à jour")
            except Exception as e:
                print(f"⚠️ Erreur mise à jour interface: {e}")
            
            print("=== RECHARGEMENT TERMINÉ AVEC SUCCÈS ===")
            self.report({'INFO'}, "Addon rechargé avec succès! Propriétés conservées.")
            return {'FINISHED'}
            
        except Exception as e:
            error_msg = f"Erreur critique lors du rechargement: {str(e)}"
            print(f"❌ ERREUR CRITIQUE dans CITYGEN_OT_ReloadAddon: {error_msg}")
            print(f"Traceback: {traceback.format_exc()}")
            self.report({'ERROR'}, f"Rechargement échoué: {error_msg}")
            return {'CANCELLED'}

class CITYGEN_OT_QuickReload(bpy.types.Operator):
    bl_idname = "citygen.quick_reload"
    bl_label = "Rechargement Rapide"
    bl_description = "Rechargement rapide des modules sans désenregistrement (plus sûr)"
    bl_options = {'REGISTER'}
    
    def execute(self, context):
        try:
            print("=== RECHARGEMENT RAPIDE CITY BLOCK GENERATOR ===")
            
            import importlib
            import sys
            
            # Modules à recharger dans l'ordre
            modules_order = [
                "city_block_generator_6_12.generator",
                "city_block_generator_6_12.operators", 
                "city_block_generator_6_12.ui"
            ]
            
            reloaded_count = 0
            for module_name in modules_order:
                if module_name in sys.modules:
                    try:
                        importlib.reload(sys.modules[module_name])
                        print(f"✅ {module_name.split('.')[-1]} rechargé")
                        reloaded_count += 1
                    except Exception as e:
                        print(f"⚠️ Erreur {module_name}: {e}")
                else:
                    print(f"⚠️ Module {module_name} non trouvé")
            
            # Forcer la mise à jour de l'interface
            for area in context.screen.areas:
                if area.type == 'VIEW_3D':
                    for region in area.regions:
                        if region.type == 'UI':
                            region.tag_redraw()
            
            print(f"=== RECHARGEMENT RAPIDE TERMINÉ: {reloaded_count} modules ===")
            self.report({'INFO'}, f"Rechargement rapide terminé ({reloaded_count} modules)")
            return {'FINISHED'}
            
        except Exception as e:
            error_msg = f"Erreur rechargement rapide: {str(e)}"
            print(f"❌ ERREUR: {error_msg}")
            self.report({'ERROR'}, error_msg)
            return {'CANCELLED'}

class CITYGEN_OT_DeployAddon(bpy.types.Operator):
    bl_idname = "citygen.deploy_addon"
    bl_label = "Déployer Addon"
    bl_description = "Copie automatiquement les fichiers de l'addon vers le répertoire Blender"
    bl_options = {'REGISTER'}
    
    def execute(self, context):
        try:
            import os
            import shutil
            from pathlib import Path
            
            print("=== DÉPLOIEMENT AUTOMATIQUE ADDON ===")
            
            # Chemins configurés
            addon_name = "city_block_generator_6_12"
            
            # Trouver le répertoire source (où se trouve cet addon actuellement)
            current_file = __file__
            source_dir = os.path.dirname(current_file)
            
            # Répertoire de destination dans Blender
            import bpy
            user_path = bpy.utils.resource_path('USER')
            target_dir = os.path.join(user_path, "scripts", "addons", addon_name)
            
            print(f"📁 Source: {source_dir}")
            print(f"📁 Destination: {target_dir}")
            
            # Fichiers à copier
            files_to_copy = ["__init__.py", "generator.py", "operators.py", "ui.py", "reload_addon.py"]
            
            # Créer le répertoire de destination
            Path(target_dir).mkdir(parents=True, exist_ok=True)
            
            # Copier les fichiers
            copied_count = 0
            for filename in files_to_copy:
                source_path = os.path.join(source_dir, filename)
                target_path = os.path.join(target_dir, filename)
                
                if os.path.exists(source_path):
                    try:
                        shutil.copy2(source_path, target_path)
                        copied_count += 1
                        print(f"✅ {filename} copié")
                    except Exception as e:
                        print(f"❌ Erreur copie {filename}: {e}")
                else:
                    print(f"⚠️ {filename} introuvable")
            
            if copied_count == len(files_to_copy):
                print(f"🎉 Déploiement réussi! {copied_count} fichiers copiés")
                self.report({'INFO'}, f"Addon déployé avec succès ({copied_count} fichiers)")
                
                # Proposer de recharger l'addon
                self.report({'INFO'}, "Utilisez 'Rechargement Complet' pour activer les changements")
                return {'FINISHED'}
            else:
                print(f"⚠️ Déploiement partiel: {copied_count}/{len(files_to_copy)} fichiers")
                self.report({'WARNING'}, f"Déploiement partiel ({copied_count}/{len(files_to_copy)} fichiers)")
                return {'FINISHED'}
                
        except Exception as e:
            error_msg = f"Erreur déploiement: {str(e)}"
            print(f"❌ {error_msg}")
            print(f"Traceback: {traceback.format_exc()}")
            self.report({'ERROR'}, error_msg)
            return {'CANCELLED'}

class CITYGEN_OT_UpdateColors(bpy.types.Operator):
    bl_idname = "citygen.update_colors"
    bl_label = "Mettre à jour les couleurs"
    bl_description = "Met à jour les couleurs des matériaux existants"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        try:
            updated_count = 0
            
            # Couleurs cibles
            colors = {
                "RoadMat": (1.0, 0.75, 0.8),  # Rose pâle
                "BuildingMat": (0.5, 1.0, 0.0),  # Vert pomme
                "SidewalkMat": (0.6, 0.6, 0.6),  # Gris
                "Commercial_District": (0.3, 0.8, 0.0),  # Vert pomme foncé
                "Residential_District": (0.5, 1.0, 0.0),  # Vert pomme
                "Industrial_District": (0.7, 1.0, 0.2),  # Vert pomme clair
            }
            
            for mat_name, color in colors.items():
                if mat_name in bpy.data.materials:
                    mat = bpy.data.materials[mat_name]
                    
                    # Mettre à jour avec nodes
                    if mat.use_nodes and mat.node_tree:
                        principled = mat.node_tree.nodes.get("Principled BSDF")
                        if principled:
                            principled.inputs[0].default_value = (*color, 1.0)
                            updated_count += 1
                            print(f"Couleur mise à jour pour {mat_name}: {color}")
                    
                    # Fallback
                    mat.diffuse_color = (*color, 1.0)
            
            if updated_count > 0:
                self.report({'INFO'}, f"Couleurs mises à jour pour {updated_count} matériaux")
            else:
                self.report({'WARNING'}, "Aucun matériau trouvé à mettre à jour")
            
            return {'FINISHED'}
            
        except Exception as e:
            error_msg = f"Erreur lors de la mise à jour des couleurs: {str(e)}"
            print(f"ERREUR CRITIQUE dans CITYGEN_OT_UpdateColors: {error_msg}")
            self.report({'ERROR'}, error_msg)
            return {'CANCELLED'}

class CITYGEN_OT_Diagnostic(bpy.types.Operator):
    bl_idname = "citygen.diagnostic"
    bl_label = "Diagnostic Addon"
    bl_description = "Effectue un diagnostic complet de l'addon et affiche les informations dans la console"
    bl_options = {'REGISTER'}
    
    def execute(self, context):
        try:
            print("\n=== DIAGNOSTIC CITY BLOCK GENERATOR ===")
            
            # Vérification de base
            print("📋 Informations de base:")
            print(f"   • Version Blender: {bpy.app.version_string}")
            print(f"   • Scène active: {context.scene.name}")
            
            # Vérification des propriétés
            print("\n🔧 Vérification des propriétés:")
            if hasattr(context.scene, 'citygen_props'):
                props = context.scene.citygen_props
                print("   ✅ Propriétés citygen_props: PRÉSENTES")
                
                # Test d'accès aux propriétés
                try:
                    print(f"   • Largeur: {props.width}")
                    print(f"   • Longueur: {props.length}")
                    print(f"   • Étages max: {props.max_floors}")
                    print(f"   • Largeur routes: {props.road_width}")
                    print("   ✅ Toutes les propriétés accessibles")
                except Exception as e:
                    print(f"   ❌ Erreur d'accès aux propriétés: {e}")
            else:
                print("   ❌ Propriétés citygen_props: MANQUANTES")
            
            # Vérification des classes
            print("\n🏗️ Vérification des classes:")
            classes_to_check = [
                ('CITYGEN_OT_Generate', 'Opérateur de génération'),
                ('CITYGEN_OT_ResetProperties', 'Opérateur de réinitialisation'),
                ('CITYGEN_PT_Panel', 'Panneau UI'),
                ('CityGenProperties', 'Groupe de propriétés')
            ]
            
            for class_name, description in classes_to_check:
                if hasattr(bpy.types, class_name):
                    print(f"   ✅ {description}: ENREGISTRÉ")
                else:
                    print(f"   ❌ {description}: MANQUANT")
            
            # Vérification de l'interface
            print("\n🖥️ Vérification de l'interface:")
            ui_visible = False
            for area in context.screen.areas:
                if area.type == 'VIEW_3D':
                    for region in area.regions:
                        if region.type == 'UI':
                            ui_visible = True
                            break
            
            if ui_visible:
                print("   ✅ Sidebar 3D: VISIBLE")
            else:
                print("   ⚠️ Sidebar 3D: NON VISIBLE (appuyez sur N)")
            
            # Instructions
            print("\n📋 Instructions:")
            print("   1. Si des éléments sont MANQUANTS, cliquez 'Réinitialiser Paramètres'")
            print("   2. Si le panneau n'apparaît pas, appuyez sur N dans la vue 3D")
            print("   3. Cherchez l'onglet 'CityGen' dans la sidebar")
            print("   4. Si problème persiste, redémarrez Blender")
            
            print("\n=== FIN DIAGNOSTIC ===\n")
            
            self.report({'INFO'}, "Diagnostic terminé - Voir la console pour les détails")
            return {'FINISHED'}
            
        except Exception as e:
            error_msg = f"Erreur durant le diagnostic: {str(e)}"
            print(f"❌ ERREUR DIAGNOSTIC: {error_msg}")
            print(f"Traceback: {traceback.format_exc()}")
            self.report({'ERROR'}, error_msg)
            return {'CANCELLED'}

# Version ultra-simplifiée pour résoudre le problème d'enregistrement
class CBG_Properties(bpy.types.PropertyGroup):
    """Propriétés ultra-simples pour City Block Generator"""
    
    width = bpy.props.IntProperty(default=5, min=1, max=50)
    length = bpy.props.IntProperty(default=5, min=1, max=50)
    max_floors = bpy.props.IntProperty(default=8, min=1, max=100)
    road_width = bpy.props.FloatProperty(default=4.0, min=0.5, max=20.0)

classes = [CBG_Properties, CITYGEN_OT_Generate, CITYGEN_OT_RegenRoads, CITYGEN_OT_ReloadAddon, CITYGEN_OT_QuickReload, CITYGEN_OT_DeployAddon, CITYGEN_OT_UpdateColors, CITYGEN_OT_Diagnostic]

def register():
    """Enregistre les classes avec gestion d'erreurs robuste - Version complète"""
    try:
        print("=== Début d'enregistrement City Block Generator ===")
        
        # ÉTAPE 1: Enregistrer CBG_Properties EN PREMIER
        try:
            print("🔹 Enregistrement CBG_Properties...")
            bpy.utils.register_class(CBG_Properties)
            print("✅ CBG_Properties enregistrée avec succès")
            
            # Vérifier immédiatement l'enregistrement
            if hasattr(bpy.types, 'CBG_Properties'):
                print("   ✓ CBG_Properties accessible dans bpy.types")
            else:
                print("   ❌ CBG_Properties NON accessible dans bpy.types")
                raise Exception("CBG_Properties non trouvée après enregistrement")
                
        except Exception as e:
            print(f"❌ ERREUR CRITIQUE: Impossible d'enregistrer CBG_Properties: {e}")
            return
        
        # ÉTAPE 2: Créer le lien Scene.citygen_props
        try:
            print("🔗 Création du lien Scene.citygen_props...")
            bpy.types.Scene.citygen_props = bpy.props.PointerProperty(type=CBG_Properties)
            print("✅ Lien Scene.citygen_props créé avec succès")
            
        except Exception as e:
            print(f"❌ ERREUR lors de la création du lien: {e}")
            print(f"Traceback: {traceback.format_exc()}")
            return
        
        # ÉTAPE 3: Enregistrer les autres classes (opérateurs, etc.)
        remaining_classes = [cls for cls in classes if cls.__name__ != 'CBG_Properties']
        for i, cls in enumerate(remaining_classes):
            try:
                print(f"� Enregistrement {cls.__name__}...")
                bpy.utils.register_class(cls)
                print(f"✅ {cls.__name__} enregistrée avec succès")
                
            except Exception as e:
                print(f"❌ ERREUR lors de l'enregistrement de {cls.__name__}: {str(e)}")
                # Continuer avec les autres classes
        
        # ÉTAPE 4: Test final et initialisation
        try:
            print("🧪 Test final des propriétés...")
            
            # Créer une fonction pour initialiser les propriétés par défaut
            def init_default_props():
                """Initialise les propriétés par défaut pour toutes les scènes"""
                try:
                    if hasattr(bpy, 'data') and hasattr(bpy.data, 'scenes'):
                        for scene in bpy.data.scenes:
                            if hasattr(scene, 'citygen_props'):
                                props = scene.citygen_props
                                # Forcer l'initialisation des valeurs par défaut
                                if not hasattr(props, 'width') or props.width == 0:
                                    props.width = 5
                                if not hasattr(props, 'length') or props.length == 0:
                                    props.length = 5
                                if not hasattr(props, 'max_floors') or props.max_floors == 0:
                                    props.max_floors = 8
                                print(f"   ✓ Propriétés initialisées pour {scene.name}")
                except Exception as e:
                    print(f"   ⚠️ Erreur initialisation: {e}")
            
            # Appeler l'initialisation si possible
            try:
                init_default_props()
            except:
                print("   📝 Initialisation différée (normal au démarrage)")
                
        except Exception as e:
            print(f"⚠️ Erreur lors du test final: {e}")
        
        print("=== City Block Generator: Enregistrement terminé ===")
        
    except Exception as e:
        print(f"❌ ERREUR CRITIQUE lors de l'enregistrement: {str(e)}")
        print(f"Traceback: {traceback.format_exc()}")

def unregister():
    """Désenregistre les classes avec gestion d'erreurs robuste"""
    try:
        print("=== Début de désenregistrement City Block Generator ===")
        
        # Désenregistrer le gestionnaire de rappel
        try:
            if init_citygen_props in bpy.app.handlers.load_post:
                bpy.app.handlers.load_post.remove(init_citygen_props)
                print("Gestionnaire de rappel City Generator désenregistré")
        except Exception as e:
            print(f"Erreur lors du désenregistrement du gestionnaire: {e}")
        
        # Désenregistrer les propriétés avec gestion d'erreurs
        try:
            if hasattr(bpy.types.Scene, "citygen_props"):
                del bpy.types.Scene.citygen_props
                print("Propriétés citygen_props désenregistrées avec succès")
        except Exception as e:
            print(f"ERREUR lors du désenregistrement des propriétés: {str(e)}")
        
        # Désenregistrer chaque classe individuellement avec gestion d'erreurs
        for cls in reversed(classes):
            try:
                bpy.utils.unregister_class(cls)
                print(f"Classe {cls.__name__} désenregistrée avec succès")
            except Exception as e:
                print(f"ERREUR lors du désenregistrement de {cls.__name__}: {str(e)}")
                # Continuer avec les autres classes
        
        print("=== City Block Generator: Désenregistrement terminé ===")
        
    except Exception as e:
        print(f"ERREUR CRITIQUE lors du désenregistrement: {str(e)}")
        print(f"Traceback: {traceback.format_exc()}")