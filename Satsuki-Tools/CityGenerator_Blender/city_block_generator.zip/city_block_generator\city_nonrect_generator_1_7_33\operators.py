def register():
    print("Operators registered")

def unregister():
    print("Operators unregistered")