def register():
    print("Panels registered")

def unregister():
    print("Panels unregistered")