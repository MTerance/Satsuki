def register():
    print("Core registered")

def unregister():
    print("Core unregistered")