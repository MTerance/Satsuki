def register():
    print("Properties registered")

def unregister():
    print("Properties unregistered")