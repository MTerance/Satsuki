bl_info = {
    "name": "Tokyo City Generator v2.1.3 REALISTIC ROADS",
    "author": "Tokyo Urban Designer",
    "version": (2, 1, 3),
    "blender": (4, 0, 0),
    "location": "View3D > Sidebar > Tokyo",
    "description": "Realistic Tokyo city with proper diagonal roads and intersections!",
    "category": "Add Mesh",
}

import bpy
from bpy.props import IntProperty, FloatProperty, EnumProperty, BoolProperty
from bpy.types import Operator, Panel
import bmesh
import mathutils
import random
import math

# ===================================================================
# PROPRIÉTÉS SIMPLES
# ===================================================================

class TokyoSimpleProperties(bpy.types.PropertyGroup):
    """Propriétés simplifiées - seulement l'essentiel !"""
    
    # PARAMÈTRES DE BASE (4 seulement !)
    city_size: IntProperty(
        name="City Size", 
        description="Size of the city (3=small, 7=large)",
        default=5, min=3, max=10
    )
    
    building_height: EnumProperty(
        name="Building Style",
        description="Overall building height style",
        items=[
            ('LOW', "Low Rise", "Small buildings (3-15m) - Residential style"),
            ('MIXED', "Mixed", "Varied heights (5-40m) - Realistic Tokyo"),
            ('HIGH', "High Rise", "Tall buildings (15-60m) - Business district"),
        ],
        default='MIXED'
    )
    
    density: FloatProperty(
        name="Density",
        description="How packed the city is",
        default=0.7, min=0.3, max=1.0, subtype='FACTOR'
    )
    
    use_textures: BoolProperty(
        name="Better Materials",
        description="Use improved materials (slower but prettier)",
        default=True
    )

# ===================================================================
# GÉNÉRATEUR SIMPLE ET EFFICACE
# ===================================================================

class TOKYO_SIMPLE_OT_generate(Operator):
    """Generate Tokyo city - Simple and effective!"""
    bl_idname = "tokyo_simple.generate"
    bl_label = "Generate Tokyo City"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        props = context.scene.tokyo_simple
        
        # Nettoyer la scène
        self.clear_scene()
        
        # Générer la ville
        result = self.generate_tokyo_city(
            size=props.city_size,
            style=props.building_height,
            density=props.density,
            use_materials=props.use_textures
        )
        
        self.report({'INFO'}, 
            f"Tokyo city generated! {result['buildings']} buildings, {result['roads']} roads")
        
        return {'FINISHED'}
    
    def clear_scene(self):
        """Supprimer les objets Tokyo existants"""
        prefixes = ["Tokyo_Building_", "Tokyo_Road_", "Tokyo_Sidewalk_"]
        for obj in list(bpy.data.objects):
            if any(obj.name.startswith(prefix) for prefix in prefixes):
                bpy.data.objects.remove(obj, do_unlink=True)
    
    def generate_tokyo_city(self, size, style, density, use_materials):
        """Générateur principal - simple et efficace"""
        
        print(f"🏙️ Generating Tokyo city {size}x{size} - Style: {style}")
        
        block_size = 16.0  # Taille des blocs
        road_width = 4.0   # Largeur des routes
        
        buildings = []
        roads = []
        
        # ÉTAPE 1: Créer les routes AVANT les bâtiments
        roads = self.create_road_network(size, block_size, road_width)
        
        # ÉTAPE 2: Créer les bâtiments dans les espaces libres
        buildings = self.create_buildings(size, block_size, road_width, style, density, use_materials)
        
        return {
            'buildings': len(buildings),
            'roads': len(roads)
        }
    
    def create_road_network(self, size, block_size, road_width):
        """Créer le réseau de routes varié avec trottoirs"""
        roads = []
        sidewalks = []
        
        # Largeurs de routes variées pour plus de réalisme
        main_road_width = road_width * 1.5  # Routes principales plus larges
        secondary_road_width = road_width * 0.8  # Routes secondaires plus étroites
        
        # Routes horizontales avec variation
        for i in range(size + 1):
            y = i * block_size - (size * block_size) / 2
            
            # Alterner entre routes principales et secondaires
            is_main_road = (i == 0 or i == size or i == size // 2)
            current_width = main_road_width if is_main_road else secondary_road_width
            
            # Créer la route
            bpy.ops.mesh.primitive_cube_add(
                size=1,
                location=(0, y, 0.05)
            )
            road = bpy.context.active_object
            road.scale = (size * block_size + current_width, current_width, 0.1)
            road.name = f"Tokyo_Road_H_{i}_{'Main' if is_main_road else 'Sec'}"
            
            bpy.ops.object.transform_apply(scale=True)
            self.apply_road_material(road, is_main_road)
            roads.append(road)
            
            # Créer les trottoirs pour cette route
            sidewalk_width = 1.5
            for side in [-1, 1]:  # Deux côtés de la route
                sidewalk_y = y + side * (current_width/2 + sidewalk_width/2)
                
                bpy.ops.mesh.primitive_cube_add(
                    size=1,
                    location=(0, sidewalk_y, 0.15)
                )
                sidewalk = bpy.context.active_object
                sidewalk.scale = (size * block_size + current_width, sidewalk_width, 0.2)
                sidewalk.name = f"Tokyo_Sidewalk_H_{i}_{side}"
                
                bpy.ops.object.transform_apply(scale=True)
                self.apply_sidewalk_material(sidewalk)
                sidewalks.append(sidewalk)
        
        # Routes verticales avec variation
        for i in range(size + 1):
            x = i * block_size - (size * block_size) / 2
            
            is_main_road = (i == 0 or i == size or i == size // 2)
            current_width = main_road_width if is_main_road else secondary_road_width
            
            # Créer la route
            bpy.ops.mesh.primitive_cube_add(
                size=1,
                location=(x, 0, 0.05)
            )
            road = bpy.context.active_object
            road.scale = (current_width, size * block_size + current_width, 0.1)
            road.name = f"Tokyo_Road_V_{i}_{'Main' if is_main_road else 'Sec'}"
            
            bpy.ops.object.transform_apply(scale=True)
            self.apply_road_material(road, is_main_road)
            roads.append(road)
            
            # Créer les trottoirs pour cette route
            sidewalk_width = 1.5
            for side in [-1, 1]:
                sidewalk_x = x + side * (current_width/2 + sidewalk_width/2)
                
                bpy.ops.mesh.primitive_cube_add(
                    size=1,
                    location=(sidewalk_x, 0, 0.15)
                )
                sidewalk = bpy.context.active_object
                sidewalk.scale = (sidewalk_width, size * block_size + current_width, 0.2)
                sidewalk.name = f"Tokyo_Sidewalk_V_{i}_{side}"
                
                bpy.ops.object.transform_apply(scale=True)
                self.apply_sidewalk_material(sidewalk)
                sidewalks.append(sidewalk)
        
        # Ajouter des routes diagonales pour briser l'uniformité
        if size >= 3:  # Routes diagonales dès les petites villes
            self.add_diagonal_roads(size, block_size, roads)
        
        return roads + sidewalks
    
    def create_buildings(self, size, block_size, road_width, style, density, use_materials):
        """Créer les bâtiments avec espacement pour trottoirs ET routes diagonales"""
        buildings = []
        
        # Configuration des hauteurs selon le style
        height_configs = {
            'LOW': {'min': 3, 'max': 15, 'avg': 8},
            'MIXED': {'min': 5, 'max': 40, 'avg': 18},
            'HIGH': {'min': 15, 'max': 60, 'avg': 30}
        }
        
        config = height_configs[style]
        
        # Créer les bâtiments bloc par bloc
        for grid_x in range(size):
            for grid_y in range(size):
                
                # Position du centre du bloc
                center_x = grid_x * block_size - (size * block_size) / 2 + block_size / 2
                center_y = grid_y * block_size - (size * block_size) / 2 + block_size / 2
                
                # Zone disponible pour les bâtiments (en évitant routes ET trottoirs ET diagonales)
                sidewalk_space = 4.0  # Espace pour trottoirs + marge pour diagonales
                available_width = block_size - road_width - sidewalk_space * 2
                available_depth = block_size - road_width - sidewalk_space * 2
                
                # S'assurer qu'il y a assez de place
                if available_width < 3 or available_depth < 3:
                    continue
                
                # Éviter les zones de passage des diagonales principales
                # Éviter la zone centrale où passent les diagonales 45° et 135°
                distance_from_center = max(abs(grid_x - size/2), abs(grid_y - size/2))
                is_diagonal_zone = (grid_x == grid_y) or (grid_x + grid_y == size - 1)
                
                # Réduire la densité dans les zones de diagonales
                density_modifier = 1.0
                if is_diagonal_zone:
                    density_modifier = 0.5  # Moins de bâtiments sur les diagonales
                
                # Nombre de bâtiments dans ce bloc selon la densité modifiée
                buildings_per_block = max(0, int(3 * density * density_modifier))
                
                if buildings_per_block == 0:
                    continue
                
                for i in range(buildings_per_block):
                    
                    # Position aléatoire dans le bloc disponible (plus restreinte)
                    max_offset = min(available_width/6, available_depth/6)
                    offset_x = random.uniform(-max_offset, max_offset)
                    offset_y = random.uniform(-max_offset, max_offset)
                    
                    building_x = center_x + offset_x
                    building_y = center_y + offset_y
                    
                    # Vérifier qu'on n'est pas sur une diagonale calculée
                    if self.is_on_diagonal_path(building_x, building_y, size, block_size):
                        continue  # Skip ce bâtiment
                    
                    # Dimensions du bâtiment (plus petites pour laisser place)
                    width = random.uniform(2.5, 5.5)
                    depth = random.uniform(2.5, 5.5)
                    
                    # Hauteur selon le style + variation
                    base_height = config['avg']
                    variation = random.uniform(config['min'], config['max'])
                    height = (base_height + variation) / 2
                    
                    # Effet de centre-ville
                    center_distance = math.sqrt((grid_x - size/2)**2 + (grid_y - size/2)**2)
                    max_distance = math.sqrt((size/2)**2 + (size/2)**2)
                    center_factor = 1.0 - (center_distance / max_distance)
                    
                    if style == 'MIXED':
                        height *= (0.7 + 0.6 * center_factor)
                    
                    # Créer le bâtiment
                    bpy.ops.mesh.primitive_cube_add(
                        size=1,
                        location=(building_x, building_y, height/2)
                    )
                    building = bpy.context.active_object
                    building.scale = (width, depth, height)
                    building.name = f"Tokyo_Building_{grid_x}_{grid_y}_{i}"
                    
                    bpy.ops.object.transform_apply(scale=True)
                    
                    # Appliquer matériau
                    if use_materials:
                        self.apply_building_material(building, height, style)
                    else:
                        self.apply_basic_material(building)
                    
                    buildings.append(building)
        
        return buildings
    
    def is_on_diagonal_path(self, x, y, size, block_size):
        """Vérifier si une position est sur le chemin d'une diagonale"""
        center_size = size * block_size
        
        # Vérifier diagonale 45° (coin inf gauche -> coin sup droit)
        # Équation de droite: y = x
        if abs(y - x) < block_size / 3:  # Tolérance pour largeur de route
            return True
        
        # Vérifier diagonale 135° (coin inf droit -> coin sup gauche)  
        # Équation: y = -x
        if abs(y + x) < block_size / 3:
            return True
        
        # Vérifier autres diagonales selon taille
        if size >= 5:
            # Diagonale 30° approximative
            if abs(y - 0.577 * x) < block_size / 4:  # tan(30°) ≈ 0.577
                return True
        
        return False
    
    def apply_road_material(self, obj, is_main_road=False):
        """Matériau varié pour les routes selon leur importance"""
        mat_name = "Tokyo_Road_Main" if is_main_road else "Tokyo_Road_Secondary"
        mat = bpy.data.materials.new(name=mat_name)
        mat.use_nodes = True
        
        bsdf = mat.node_tree.nodes["Principled BSDF"]
        
        if is_main_road:
            # Routes principales - asphalte plus foncé et lisse
            bsdf.inputs['Base Color'].default_value = (0.12, 0.12, 0.12, 1.0)
            bsdf.inputs['Roughness'].default_value = 0.7
        else:
            # Routes secondaires - asphalte plus clair et texturé
            bsdf.inputs['Base Color'].default_value = (0.18, 0.18, 0.18, 1.0)
            bsdf.inputs['Roughness'].default_value = 0.95
        
        obj.data.materials.append(mat)
    
    def apply_sidewalk_material(self, obj):
        """Matériau spécifique pour les trottoirs"""
        mat = bpy.data.materials.new(name="Tokyo_Sidewalk")
        mat.use_nodes = True
        
        bsdf = mat.node_tree.nodes["Principled BSDF"]
        # Couleur béton claire pour les trottoirs
        bsdf.inputs['Base Color'].default_value = (0.7, 0.7, 0.75, 1.0)
        bsdf.inputs['Roughness'].default_value = 0.8
        # Removed Specular property for Blender 4.0+ compatibility
        
        obj.data.materials.append(mat)
    
    def add_diagonal_roads(self, size, block_size, roads):
        """Ajouter des routes diagonales qui respectent les intersections"""
        diagonal_roads = []
        
        # Route diagonale principale (45°) - Connecte les intersections
        if size >= 3:
            # Points d'intersection de la grille pour calculer les vraies connexions
            intersections = []
            for i in range(size + 1):
                for j in range(size + 1):
                    x = i * block_size - (size * block_size) / 2
                    y = j * block_size - (size * block_size) / 2
                    intersections.append((x, y))
            
            # Diagonale principale coin à coin
            start_x = -size * block_size / 2
            start_y = -size * block_size / 2
            end_x = size * block_size / 2
            end_y = size * block_size / 2
            
            # Créer la route diagonale avec trottoirs
            center_x = (start_x + end_x) / 2
            center_y = (start_y + end_y) / 2
            length = math.sqrt((end_x - start_x)**2 + (end_y - start_y)**2)
            angle = math.atan2(end_y - start_y, end_x - start_x)
            
            # Route diagonale principale
            bpy.ops.mesh.primitive_cube_add(size=1, location=(center_x, center_y, 0.05))
            diagonal_road = bpy.context.active_object
            diagonal_road.scale = (length, 4.0, 0.1)  # Largeur comme route principale
            diagonal_road.rotation_euler = (0, 0, angle)
            diagonal_road.name = "Tokyo_Road_Diagonal_45_Main"
            bpy.ops.object.transform_apply(scale=True)
            self.apply_road_material(diagonal_road, True)  # Route principale
            diagonal_roads.append(diagonal_road)
            
            # Trottoirs pour la diagonale 45°
            self.add_diagonal_sidewalks(center_x, center_y, length, angle, "45", diagonal_roads)
        
        # Route diagonale inverse (135°) - Pour créer un X
        if size >= 4:
            start_x = size * block_size / 2
            start_y = -size * block_size / 2
            end_x = -size * block_size / 2
            end_y = size * block_size / 2
            
            center_x = (start_x + end_x) / 2
            center_y = (start_y + end_y) / 2
            length = math.sqrt((end_x - start_x)**2 + (end_y - start_y)**2)
            angle = math.atan2(end_y - start_y, end_x - start_x)
            
            bpy.ops.mesh.primitive_cube_add(size=1, location=(center_x, center_y, 0.05))
            diagonal_road = bpy.context.active_object
            diagonal_road.scale = (length, 4.0, 0.1)
            diagonal_road.rotation_euler = (0, 0, angle)
            diagonal_road.name = "Tokyo_Road_Diagonal_135_Main"
            bpy.ops.object.transform_apply(scale=True)
            self.apply_road_material(diagonal_road, True)
            diagonal_roads.append(diagonal_road)
            
            # Trottoirs pour la diagonale 135°
            self.add_diagonal_sidewalks(center_x, center_y, length, angle, "135", diagonal_roads)
        
        # Routes secondaires diagonales - Connectent les intersections intermédiaires
        if size >= 6:
            # Diagonale courte connectant intersections spécifiques
            mid_point = size // 2
            
            # Diagonale du quart inférieur vers le centre
            start_x = (mid_point - 1) * block_size - (size * block_size) / 2
            start_y = -size * block_size / 2
            end_x = mid_point * block_size - (size * block_size) / 2
            end_y = (mid_point - 1) * block_size - (size * block_size) / 2
            
            center_x = (start_x + end_x) / 2
            center_y = (start_y + end_y) / 2
            length = math.sqrt((end_x - start_x)**2 + (end_y - start_y)**2)
            angle = math.atan2(end_y - start_y, end_x - start_x)
            
            bpy.ops.mesh.primitive_cube_add(size=1, location=(center_x, center_y, 0.05))
            diagonal_road = bpy.context.active_object
            diagonal_road.scale = (length, 2.5, 0.1)  # Plus étroite = route secondaire
            diagonal_road.rotation_euler = (0, 0, angle)
            diagonal_road.name = "Tokyo_Road_Diagonal_Secondary_1"
            bpy.ops.object.transform_apply(scale=True)
            self.apply_road_material(diagonal_road, False)  # Route secondaire
            diagonal_roads.append(diagonal_road)
            
            # Trottoirs pour diagonale secondaire
            self.add_diagonal_sidewalks(center_x, center_y, length, angle, "Sec1", diagonal_roads)
        
        roads.extend(diagonal_roads)
        return diagonal_roads
    
    def add_diagonal_sidewalks(self, center_x, center_y, length, angle, road_id, diagonal_roads):
        """Ajouter des trottoirs le long des routes diagonales"""
        sidewalk_width = 1.5
        
        # Deux trottoirs de chaque côté de la route diagonale
        for side in [-1, 1]:
            # Calculer la position du trottoir perpendiculairement à la route
            offset_x = side * (2.5 + sidewalk_width/2) * math.sin(angle)  # Perpendiculaire
            offset_y = side * (2.5 + sidewalk_width/2) * (-math.cos(angle))
            
            sidewalk_x = center_x + offset_x
            sidewalk_y = center_y + offset_y
            
            bpy.ops.mesh.primitive_cube_add(
                size=1,
                location=(sidewalk_x, sidewalk_y, 0.15)
            )
            sidewalk = bpy.context.active_object
            sidewalk.scale = (length, sidewalk_width, 0.2)
            sidewalk.rotation_euler = (0, 0, angle)
            sidewalk.name = f"Tokyo_Sidewalk_Diagonal_{road_id}_{side}"
            
            bpy.ops.object.transform_apply(scale=True)
            self.apply_sidewalk_material(sidewalk)
            diagonal_roads.append(sidewalk)
    
    def add_curved_roads(self, size, block_size, diagonal_roads):
        """Ajouter des routes légèrement courbes pour plus d'organique"""
        # Route courbe en S
        curve_points = []
        segments = 8
        
        start_x = -size * block_size / 3
        end_x = size * block_size / 3
        amplitude = block_size / 2  # Amplitude de la courbe
        
        for i in range(segments + 1):
            t = i / segments
            x = start_x + t * (end_x - start_x)
            # Courbe sinusoïdale simple
            y = amplitude * math.sin(t * math.pi * 2) 
            curve_points.append((x, y))
        
        # Créer segments de route courbe
        for i in range(len(curve_points) - 1):
            x1, y1 = curve_points[i]
            x2, y2 = curve_points[i + 1]
            
            center_x = (x1 + x2) / 2
            center_y = (y1 + y2) / 2
            length = math.sqrt((x2 - x1)**2 + (y2 - y1)**2)
            angle = math.atan2(y2 - y1, x2 - x1)
            
            bpy.ops.mesh.primitive_cube_add(
                size=1,
                location=(center_x, center_y, 0.05)
            )
            curve_segment = bpy.context.active_object
            curve_segment.scale = (length, 1.5, 0.1)
            curve_segment.rotation_euler = (0, 0, angle)
            curve_segment.name = f"Tokyo_Road_Curve_Segment_{i}"
            
            bpy.ops.object.transform_apply(scale=True)
            self.apply_road_material(curve_segment, False)
            diagonal_roads.append(curve_segment)
    
    def apply_building_material(self, obj, height, style):
        """Matériau adapté selon la hauteur et le style"""
        
        # Déterminer le type de bâtiment selon la hauteur
        if height > 35:
            mat_type = "skyscraper"
            base_color = (0.6, 0.7, 0.9, 1.0)  # Bleu moderne
            metallic = 0.7
            roughness = 0.3
        elif height > 20:
            mat_type = "office"
            base_color = (0.7, 0.7, 0.8, 1.0)  # Gris professionnel
            metallic = 0.3
            roughness = 0.6
        elif height > 10:
            mat_type = "apartment"
            base_color = (0.8, 0.75, 0.7, 1.0)  # Beige résidentiel
            metallic = 0.1
            roughness = 0.8
        else:
            mat_type = "house"
            base_color = (0.9, 0.8, 0.7, 1.0)  # Brun chaleureux
            metallic = 0.05
            roughness = 0.9
        
        # Variation de couleur pour éviter l'uniformité
        color_variation = [random.uniform(0.85, 1.15) for _ in range(3)]
        varied_color = tuple(min(1.0, base_color[i] * color_variation[i]) for i in range(3)) + (1.0,)
        
        mat = bpy.data.materials.new(name=f"Tokyo_{mat_type}_{int(height)}m")
        mat.use_nodes = True
        
        bsdf = mat.node_tree.nodes["Principled BSDF"]
        bsdf.inputs['Base Color'].default_value = varied_color
        bsdf.inputs['Metallic'].default_value = metallic
        bsdf.inputs['Roughness'].default_value = roughness
        
        # Émission légère pour les gratte-ciels (fenêtres éclairées)
        if height > 35:
            bsdf.inputs['Emission Strength'].default_value = 0.03
            bsdf.inputs['Emission Color'].default_value = (1.0, 0.9, 0.7, 1.0)
        
        obj.data.materials.append(mat)
    
    def apply_basic_material(self, obj):
        """Matériau basique uniforme"""
        mat = bpy.data.materials.new(name="Tokyo_Basic_Building")
        mat.use_nodes = True
        
        bsdf = mat.node_tree.nodes["Principled BSDF"]
        bsdf.inputs['Base Color'].default_value = (0.8, 0.8, 0.8, 1.0)
        bsdf.inputs['Roughness'].default_value = 0.7
        
        obj.data.materials.append(mat)

# ===================================================================
# INTERFACE ULTRA-SIMPLE
# ===================================================================

class TOKYO_SIMPLE_PT_panel(Panel):
    """Panneau simple - 4 paramètres maximum !"""
    bl_label = "Tokyo City Generator"
    bl_idname = "TOKYO_SIMPLE_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Tokyo'
    
    def draw(self, context):
        layout = self.layout
        props = context.scene.tokyo_simple
        
        # En-tête simple
        box = layout.box()
        box.label(text="🏙️ Tokyo Generator v2.1.3 REALISTIC", icon='MESH_CUBE')
        
        # Les 4 paramètres essentiels
        main_box = layout.box()
        main_box.label(text="Settings", icon='SETTINGS')
        
        col = main_box.column(align=True)
        col.prop(props, "city_size")
        col.prop(props, "building_height")
        col.prop(props, "density", slider=True)
        col.prop(props, "use_textures")
        
        # Bouton de génération - GROS et visible
        layout.separator()
        row = layout.row()
        row.scale_y = 2.0
        row.operator("tokyo_simple.generate", text="🏗️ Generate Tokyo City", icon='MESH_CUBE')
        
        # Bouton de nettoyage
        layout.separator()
        clear_row = layout.row()
        clear_row.operator("tokyo_simple.clear", text="🗑️ Clear City", icon='TRASH')

class TOKYO_SIMPLE_OT_clear(Operator):
    """Clear all Tokyo objects"""
    bl_idname = "tokyo_simple.clear"
    bl_label = "Clear Tokyo City"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        prefixes = ["Tokyo_Building_", "Tokyo_Road_", "Tokyo_Sidewalk_"]
        count = 0
        
        for obj in list(bpy.data.objects):
            if any(obj.name.startswith(prefix) for prefix in prefixes):
                bpy.data.objects.remove(obj, do_unlink=True)
                count += 1
        
        self.report({'INFO'}, f"Cleared {count} Tokyo objects")
        return {'FINISHED'}

# ===================================================================
# ENREGISTREMENT
# ===================================================================

classes = [
    TokyoSimpleProperties,
    TOKYO_SIMPLE_OT_generate,
    TOKYO_SIMPLE_OT_clear,
    TOKYO_SIMPLE_PT_panel,
]

def register():
    print("🏙️ Enregistrement Tokyo Simple v2.1...")
    
    for cls in classes:
        bpy.utils.register_class(cls)
    
    bpy.types.Scene.tokyo_simple = bpy.props.PointerProperty(type=TokyoSimpleProperties)
    
    print("✅ Tokyo Simple v2.1 enregistré - Interface simplifiée !")

def unregister():
    print("🔄 Désenregistrement Tokyo Simple v2.1...")
    
    del bpy.types.Scene.tokyo_simple
    
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    
    print("✅ Tokyo Simple v2.1 désenregistré !")

if __name__ == "__main__":
    register()