README - Pack de textures Anime Tokyo
=====================================

Ce pack contient des textures seamless pour bâtiments et gratte-ciel de style anime japonais.
Elles sont adaptées pour un usage dans Blender, Godot, Unity ou tout moteur 3D, et conçues pour se répéter
horizontalement et verticalement (512x512 px).

Contenu du pack :
-----------------
1. batiments_fenetres.png
   -> Série de textures avec fenêtres (un étage ou double fenêtre).

2. gratteciel_1.png
   -> Première série de textures pour gratte-ciel modernes (façades vitrées et structures régulières).

3. gratteciel_2.png
   -> Seconde série de textures pour gratte-ciel modernes (variantes avec cadres et vitres).

4. murs_sans_fenetre.png
   -> Série de murs modernes sans fenêtres (béton, panneaux, briques), inspirés de Tokyo.

Utilisation :
-------------
- Mapper chaque texture sur un étage de bâtiment pour répétition verticale.
- Peut être utilisée comme base diffuse, avec ajout éventuel de normal map / specular map.
- Idéal pour un rendu stylisé anime / low poly.

Auteur : Généré par IA (ChatGPT)
