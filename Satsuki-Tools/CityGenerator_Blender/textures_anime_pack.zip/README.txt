Pack de textures seamless (style anime/manga)
Catégories : routes, murs_maison, usine, gratte_ciel
Format : 512x512 PNG
